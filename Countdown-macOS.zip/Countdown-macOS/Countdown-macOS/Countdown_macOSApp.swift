//
//  Countdown_macOSApp.swift
//  Countdown-macOS
//
//  Created by Scott D. Bowen on 2/8/21.
//

import SwiftUI

@main
struct Countdown_macOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
